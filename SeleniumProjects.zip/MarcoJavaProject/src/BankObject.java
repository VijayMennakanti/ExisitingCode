
public class BankObject {

	public static void main(String[] args) {
	
		 BankTemplate pavani =new BankTemplate("vijay",0345676777 ,"vijii034","520-Mornington Avenue",2.9,1600000,9490023322L);
		 
		 
		
		 pavani.bankAccount1();
		 pavani.forBankAccountNeed();
		 pavani.depositMethod();
		 
		 
		 BankTemplate sagar= new BankTemplate("pinky", 949002332,"pinky364"," h.no:- 4-11-37/B",8.009,200000 ,226947555L);
		 sagar.bankAccount1();
		 sagar.forBankAccountNeed();
		 sagar.depositMethod();

		 

	}

}
