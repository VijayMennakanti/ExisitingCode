
public class SumObject {

	public static void main(String[] args) {
		
		 SumTemplate vijii=	new SumTemplate(8, 6, 9);
		
          vijii.nextResult();
	}

}
