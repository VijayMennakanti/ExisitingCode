
public class OverRideTemBank {

	public void depositMethod() {
		
		System.out.println("I'm trying to deposit the money from the bank");
		
	}
	
	
	
	
	
	
	
	
}
