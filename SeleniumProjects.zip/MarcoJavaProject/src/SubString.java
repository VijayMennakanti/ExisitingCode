
public class SubString {

	public static void main(String[] args) {
		
		
		String name="vijay mennakanti";
		
	System.out.println(name.substring(1));	
	System.out.println(name.substring(0, 5));
		System.out.println(name.subSequence(1, 5));

	}

}
