
public class SumTemplate {
	
	int a= 10,b=7,c=17;
	
	public SumTemplate( int a,int b,int c) {
		
		
		 int sum=a+b;
		 
		 System.out.println(sum);
		 
		}
	
public void nextResult() {
	
	
	if (a>b) {
		
		System.out.println("give control to coustmer to access system");
		
		
	}else if(b>c) {
		
		System.out.println("should not give access to the system");
		
	} else {
		
		System.out.println();
	}
	
	
}
	
	
	

}
