package Pacakage2Programmes;// 1. java programmer for in taking two numbers using scanner and printing their sum

import java.util.Scanner;

public class Program1 {

	public static void main(String[] args) {
		
		Scanner scanner= new Scanner(System.in);  // class is Scanner and memory location is scanner
		
		System.out.println("Enter first number");
		
		int firstnumber= scanner.nextInt();
		System.out.println("Enter second number");
		
		int secondnumber= scanner.nextInt();
		
		
		
		System.out.println("the sum of"+firstnumber+"and"+secondnumber+"is:"+(firstnumber+secondnumber));
		
		vijaySum();
	
scanner.close();
	}
		public static void vijaySum() {
			

			Scanner scanner= new Scanner(System.in);  // class is Scanner and memory location is scanner
			
			System.out.println("Enter first number");
			
			int firstnumber= scanner.nextInt();
			System.out.println("Enter second number");
			
			int secondnumber= scanner.nextInt();
			
			
			
			System.out.println("the sum of"+firstnumber+"and"+secondnumber+"is:"+(firstnumber+secondnumber));
			
			
			
			
		}				
				
			}
		
	


