package Pacakage2Programmes;
import Package3.Private;
public class privateMain2 {

	public static void main(String[] args) {
		Private	p=new Private();
		p.sampleMethodTwo();
		    p.setName("sagar");

		String s= p.getName();
			System.out.println(s);

		
	}

}
