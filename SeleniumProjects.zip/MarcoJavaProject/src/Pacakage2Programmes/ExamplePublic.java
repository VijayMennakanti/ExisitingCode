package Pacakage2Programmes;
import Package3.Public;          
public class ExamplePublic {

	public static void main(String[] args) {
	
   Public P= new Public();
   
   
   
	}

}
