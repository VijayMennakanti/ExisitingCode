
public class MathObject {

	public static void main(String[] args) {
		
		OverloadingMathTem pinky=new OverloadingMathTem();
		
		pinky.add(1, 2, 3);
		OverloadingMathTem annie=new OverloadingMathTem();
		annie.add(6, 6);

	}

}
