
public class BankHDFC extends OverRideTemBank {
	
public void depositMethod(int a) {
		
		System.out.println("I'm trying to deposit the from the HDFC bank");  		
}	
}

 /* This is known as overloading method using inheritance*/