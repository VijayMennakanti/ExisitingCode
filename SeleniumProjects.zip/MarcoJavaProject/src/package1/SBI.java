package package1;

public class SBI extends BANKTemplate{
	
	
	String Accountnumber;
	
public void freeGift(String a) {
	
	
	int customer = 10;
	
	if(customer>10) {
		
		
		System.out.println("if customer won more than 10 points he might get the gift");
	}else {
		
		
		System.out.println("not get the gift");
	}
	
}
	

	}


