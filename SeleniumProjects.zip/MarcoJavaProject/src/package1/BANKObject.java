package package1;

public class BANKObject {
	
	public static void main(String[] args) {
		
	BANKTemplate S=new BANKTemplate();
		
		S.accountTypeOne="Saving";
		S.accountTypeTwo="cheque";
		S.depositAccount(10000,5000);
		S.withdrawAccount(20000000000L);
		
		
	}

}
