package package1;

public class INDIAN extends BANKTemplate{

}
