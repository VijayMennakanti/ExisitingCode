package pack11;

public class FilePrintWriter1 {

	public static void main(String[] args) {
	

	}

}
