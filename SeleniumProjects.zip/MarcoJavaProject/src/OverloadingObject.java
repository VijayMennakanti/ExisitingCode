
public class OverloadingObject {

	public static void main(String[] args) {
		
		
OverloadingTemplate joseph = new OverloadingTemplate (4);
OverloadingTemplate joseph1 = new OverloadingTemplate (4,7);


		

	}
	
}