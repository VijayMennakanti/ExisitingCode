package pac6;

public class ArrayTwoDimension1 {

	public static void main(String[] args) {
	
	int[][] a= new int [3][4]; // SHORT FORM	
	
	
	a[0][0]= 9;
	a[0][1]=6;
	a[0][2]=2;
	a[0][3]=5;
	
	a[1][0]=4; 
	a[1][1]=8;
	a[1][2]=1;
	a[1][3]=3;
	
	a[2][0]=11; 
	a[2][1]=22;
	a[2][2]=33;
	a[2][3]=44;
	
	
	
	System.out.println(a[0][0]);
    System.out.println(a[0][1]);	
	System.out.println(a[0][2]);	
	System.out.println(a[0][3]);	
	System.out.println(a[1][0]);

	}

}
