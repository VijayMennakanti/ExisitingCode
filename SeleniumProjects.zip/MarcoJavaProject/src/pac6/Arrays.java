package pac6;

 
public class Arrays {

	public static void main(String[] args) {
		
	int[] a = new int [3];  // declaration //we can also declare in another way int[]={3,6,9};
	
	a[0]=3;                // assigning
	a[1]=6;
	a[2]=9;
	System.out.println(a[0]);   // accessing
	System.out.println(a[1]);
    System.out.println(a[2]);
	}

}
