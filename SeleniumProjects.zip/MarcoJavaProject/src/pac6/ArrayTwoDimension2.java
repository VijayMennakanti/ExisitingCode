package pac6;

public class ArrayTwoDimension2 {

	public static void main(String[] args) {
	
   int[][]a = {{9,6,2,5},{4,8,1,3},{11,22,33,44}};
   
   System.out.println(a.length); //3
		
System.out.println("The number of arrays :"  +a.length);
		
System.out.println("The number of array values in the first array is :"+a[0].length);
		
	}

}
