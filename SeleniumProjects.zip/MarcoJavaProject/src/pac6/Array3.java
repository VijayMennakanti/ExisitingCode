package pac6;

public class Array3 { // for loop

	public static void main(String[] args) {
		int []a= {3,6,9,8,7,5,2,4};
		
		for (int i=0;i<8;i++) {// for(int i=o;i<a.length;i++);
			
			System.out.println(a[i]);
		}

	}

}
