package pac6;

public class Array2 {

	public static void main(String[] args) {
		
		
		int []a= {3,6,9,8,7,5,2,4};
		
		System.out.println(a[0]);   
		System.out.println(a[1]);
	    System.out.println(a[2]);
        System.out.println(a.length);
	}

}
