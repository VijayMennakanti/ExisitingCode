package pac6;

public class ArrayOtherTopics {

	public static void main(String[] args) { // we cannot store different types of literals in to single variable
		                                     // solution is -OBJECT ARRAYS.
	Object []a	=new Object[3];
	
	a[0]=2.5;
	a[1]="vijay";
	a[2]=44778890L;
	
	
	
	/*Dis-advantages of Array :- 1.Fixed in size 
	 *                           2.Solution for the Fixed in size is Collection Frameworks- Array list*/
	
	

	}

}
