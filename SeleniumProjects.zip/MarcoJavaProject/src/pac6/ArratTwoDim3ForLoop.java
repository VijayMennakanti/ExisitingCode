package pac6;

public class ArratTwoDim3ForLoop {

	public static void main(String[] args) {
		
  int[][]a = {{9,6,2,5},{4,8,1,3},{11,22,33,44}};
  
  for(int i=0;i<a.length;i++) {
	  
	  
	  for (int j=0;j<a[i].length;j++) {
		  
		  
		  System.out.println(a[i][j]); // print or println
	  }
  }// we have to add  onemore println statement
  
  
	}

}
