package pac6;

public class Array4 {

	public static void main(String[] args) {
		int []a= {3,6,9,8,7,5,2,4,22,21,24,34};
	
for (int e:a) {   // for-each loop
	
	System.out.println(e);
	
}
	}

}
// we have also have another one in array that is called
// array outbound exeception 