package pack5;

public class Hdfc implements Bank {
	 
	String AccountTypeThree="Flexi";
	
	public void depositMoney() {
		
		System.out.println("deposit the money in the HDFC");
		
	}
	public void transferMoney() {
		
		System.out.println("transer the money in the HDFC");
		
	}
public void flexiMoney() {
	
	System.out.println("please open my flexi account");
	
}
}
