package pack5;

public class Axis implements Bank{
	
	
public void depositMoney() {
		
		System.out.println("deposit the money in the Axis");
		
	}
	public void transferMoney() {
		
		System.out.println("transer the money in the Axis");
		
	}
public void flexiMoney2() {
	System.out.println("please open FLEXIII");
}
}
