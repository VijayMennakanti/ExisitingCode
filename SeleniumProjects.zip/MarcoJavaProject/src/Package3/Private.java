package Package3;

public class Private {
	

	private String name=" vijay";
	
	
	private void SampleMethod() {
		
		System.out.println("inside the sample method");
		
		}
	
	public void sampleMethodTwo() {
		
		SampleMethod();
		
		System.out.println("HIIIIIIIIII");
		
	}
	
	public void setName( String a) {

	name = a;
		
	}
	
	public String getName() {
		
		
		return name;
	}
	
	
	
		}
		
	
	
	

