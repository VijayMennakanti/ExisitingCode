package Package3;

public class PublicObject {

	public static void main(String[] args) {
	
		
		Public P=new Public();
		P.sumMethod(8, 2);
		
		System.out.println();
		
	}

}
