package Package3;

public class Public {

public int a,b;
	


public void sumMethod(int a,int b) {
	
	System.out.println(a+b);

	
	
}


public void printMethod(String a ) {
	
	
	System.out.println( a );

	/* public is a keyword that accessible by the CLASSES,VARIABLES,METHODS
	 * the classes, variables,methods which having public as a keyword or Access Modifier they can be accessible inside the same packages 
	 
 once if they are in the different packages we have to use IMPORT Keyword to access the public classes, variable s and methods	 */
	
}
	
}
