package Package3;

public class PrivateMain {



	public static void main(String[] args) {
	Private	p=new Private();
	p.sampleMethodTwo();
String bu	= p.getName();
System.out.println(bu);
    p.setName("joseph");

String s= p.getName();
	System.out.println(s);
	}

}
   