package Package3;

public class WrapperClass {

	public static void main(String[] args) {
		

		
		int a= 5;
		Integer b=a;
		int c= b;
		int sum;
		
		System.out.println(a);
		System.out.println(b.toString());
		System.out.println(c);
		
		
	}

	
	
	public void sampleMethod() {
		
	
		
		
		
		
	}
	
	
	
}
