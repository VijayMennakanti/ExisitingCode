
public class HDFCDEMO {

	public static void main(String[] args) {
		
		BankHDFC h=new BankHDFC();
		h.depositMethod();
		h.depositMethod(6);

	
	}

}
