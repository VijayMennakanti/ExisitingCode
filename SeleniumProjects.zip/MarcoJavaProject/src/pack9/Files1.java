package pack9;

import java.io.File;

public class Files1 {

	public static void main(String[] args) {
		
		
	File file1	=new File("sample\\.project"); //  we can also write it as sample/.project
	
	System.out.println(file1.exists());  //  exist()method

	}

}
