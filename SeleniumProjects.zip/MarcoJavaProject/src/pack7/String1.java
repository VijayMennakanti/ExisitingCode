package pack7;

public class String1 {

	public static void main(String[] args) {
	
		
		String firstName="vijay";
		String secondName="mennakanti";   // STRING CONCATINATION
		
		String gmailId= firstName+secondName+"034"+"@"+"gmail"+"."+"com";
		
		System.out.println(gmailId);

	}

}
