package Pack4NonAccess;

public class Car extends Abstract{

	public void startCar() {
		
		System.out.println("The car has startted");
		
		
	}
	
	
}
