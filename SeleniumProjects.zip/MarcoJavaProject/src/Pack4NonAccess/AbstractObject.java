package Pack4NonAccess;

public class AbstractObject {

	public static void main(String[] args) {
		
	Car	 svdi=new Car();
		
	svdi.company="AUDI";
	System.out.println(svdi.company);

	svdi.startCar();
	svdi.stopCar();
	}
 
}
