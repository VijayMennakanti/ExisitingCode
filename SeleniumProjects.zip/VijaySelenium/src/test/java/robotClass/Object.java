package robotClass;

import java.awt.AWTException;

public class Object {

	public static void main(String[] args) throws AWTException {
		
	TemplateForUploadinngFile template = new TemplateForUploadinngFile();
		
	template.uploadFile();
	}

}
