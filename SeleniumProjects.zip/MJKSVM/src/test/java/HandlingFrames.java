
public class HandlingFrames {

	public static void main(String[] args) {
		
	}

}
