package broweser;
import org.openqa.selenium.WebDriver;
/**
 * 
 */
public class ObjectForWebDriverMethods {

	
	public static void main(String[] args) {
		
	WebDriverMethods web = new WebDriverMethods();

//\	web.differentBrowserLaunching(WebDriverMethods.driver,WebDriverMethods.browserName="Firefox" );
	
	
//	web.webDriverMethods(WebDriverMethods.driver);

   web.someMoreMethods(WebDriverMethods.driver);
	
	
	
	}

}
